<div align=center>
	<h1> Neko's Seterra Features Wizard (Firefox) </h1>
	<p>
	This directory is for Firefox-based browsers.
	<br>
	For Chromium, see the "chrome" directory.
	</p>
</div>