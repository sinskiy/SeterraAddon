/////////////////////
/* One-time stuff */
///////////////////

// Page change observer(s):

const pageObserver = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    applySettings();

    document.getElementById("NekoAddon").style.display = "block";

    const regex = /\d/; // match numbers
    if (!regex.test(window.location.toString())) {
      document.getElementById("NekoAddon").style.display = "none";
    }

    if (window.find("Uh oh! Got lost on your way?", true)) {
      location.reload();
    }
  });
});

pageObserver.observe(document.body, { childList: true, subtree: true });

const elementsToObserve = [
  "WATER",
  "BACKGROUND",
  "WATER_1_",
  "WATER_2_",
  "WATER_3_",
];
mapBackgroundChecker(elementsToObserve, (foundElementId) => {
  if (document.getElementById("Map background").checked) {
    mapBg(true);
  } else {
    mapBg(false);
  }
});

// Font switching stuff:

const oldFontstyle = document.createElement("style");
oldFontstyle.type = "text/css";

const importRule = `
    @import url('https://fonts.cdnfonts.com/css/neo-sans-pro');
    `;

if (oldFontstyle.styleSheet) {
  oldFontstyle.styleSheet.cssText = importRule;
} else {
  oldFontstyle.appendChild(document.createTextNode(importRule));
}

document.head.appendChild(oldFontstyle);

const fontStyle = document.createElement("style");
fontStyle.textContent = `
        @import url('https://fonts.cdnfonts.com/css/neo-sans-pro');
        .use-old-font *:not(.use-old-font) {
            font-family: 'Neo Sans Pro', sans-serif !important;
        }
    `;
document.head.appendChild(fontStyle);

// Remove useless space:

if (document.getElementsByClassName("seterra_adFooter__4glju")[0]) {
  document.getElementsByClassName("seterra_adFooter__4glju")[0].remove();
}

// Page zoom listener:

let previousZoom = window.devicePixelRatio;

function handleZoomChange() {
  const currentZoom = window.devicePixelRatio;
  if (currentZoom !== previousZoom) {
    previousZoom = currentZoom;

    let zoomCheckbox = document.getElementById("Center map");

    if (zoomCheckbox.checked) noLeftSpace(true);
    else noLeftSpace(false);
  }
}

window.addEventListener("resize", handleZoomChange);

//// Dark/Light mode listener:

const targetNode = document.body;

// End screen modal for listener
const modalClass =
  "modal_content__ZijTp modal_colorWhite__b1Uem modal_sizeSmall__gHON2";

const observerOptions = {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ["class"],
};

const callback = (mutationsList, observer) => {
  for (const mutation of mutationsList) {
    if (mutation.type === "childList") {
      // Check if the modal element is added
      const modalElement = document.querySelector(
        `.${modalClass.replace(/\s/g, ".")}`
      );
      if (modalElement) {
        let dmCheckbox = document.getElementById("Dark mode");

        if (dmCheckbox.checked) {
          document.querySelectorAll(
            "div.modal_content__ZijTp.modal_colorWhite__b1Uem.modal_sizeSmall__gHON2"
          )[0].style.background = "rgba(24, 26, 27, 0.55)";
          // cursor label \/
          if (
            document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          ) {
            document.getElementsByClassName(
              "game-tooltip_tooltip__w_58_"
            )[0].style.background = "rgba(24, 26, 27, 0.75)";

            var spanElement = document
              .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
              .querySelector("span")
              .querySelector("strong");

            if (spanElement) {
              spanElement.style.color = "white";
              labelColor = false;
            }
          }

          const darkBackgroundColor = "#181A1B";
          if (document.getElementsByClassName("highscore_table__oKrYg")[0]) {
            document.getElementsByClassName(
              "highscore_table__oKrYg"
            )[0].style.background = darkBackgroundColor;
          }

          const textColorWhite = "white";
          const nonLinkElements = document.querySelectorAll(
            ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
          );
          nonLinkElements.forEach((element) => {
            element.style.color = textColorWhite;
          });
        } else {
          document.querySelectorAll(
            "div.modal_content__ZijTp.modal_colorWhite__b1Uem.modal_sizeSmall__gHON2"
          )[0].style.background = "rgba(255, 255, 255, 0.55)";
          // cursor label \/
          if (
            document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          ) {
            document.getElementsByClassName(
              "game-tooltip_tooltip__w_58_"
            )[0].style.background = "rgba(255, 255, 255, 0.75)";

            var spanElement = document
              .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
              .querySelector("span")
              .querySelector("strong");

            if (spanElement) {
              spanElement.style.color = "black";
              labelColor = false;
            }
          }

          const lightBackgroundColor = "#E7E5E4";
          if (document.getElementsByClassName("highscore_table__oKrYg")[0]) {
            document.getElementsByClassName(
              "highscore_table__oKrYg"
            )[0].style.background = lightBackgroundColor;
          }

          const textColorBlack = "black";
          const nonLinkElements = document.querySelectorAll(
            ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
          );
          nonLinkElements.forEach((element) => {
            element.style.color = textColorBlack;
          });
        }

        const highlightColor1 = "#FF006E";
        const highlightColor2 = "#CC0058";
        const nekoHeader = document.getElementsByClassName("header-class")[0];
        const version = document.getElementsByClassName("version-info")[0];
        if (nekoHeader) nekoHeader.style.color = highlightColor1;
        if (version) version.style.color = highlightColor2;

        getData("ST10").then((value) => {
          if (value == "KEEP") {
            customTable(false);
          } else {
            customTable(true);
          }
        });
      }
    }
  }
};

// Create an observer instance and start observing
const themeObserver = new MutationObserver(callback);
themeObserver.observe(targetNode, observerOptions);

// top 10

const top10observer = new MutationObserver((mutationsList) => {
  mutationsList.forEach((mutation) => {
    if (mutation.type === "childList") {
      const element = document.querySelector(".highscore_table__oKrYg");
      if (element) {
        const bgColor = window.getComputedStyle(element).backgroundColor;

        // Check if the background color is white in rgb or rgba format
        if (
          bgColor === "rgb(255, 255, 255)" ||
          bgColor === "rgba(255, 255, 255, 1)"
        ) {
          getData("DMode").then((value) => {
            if (value == "DARK") {
              darkMode();
            } else {
              lightMode();
            }
          });
          getData("ST10").then((value) => {
            if (value == "KEEP") {
              customTable(false);
            } else {
              customTable(true);
            }
          });
        }
      }
    }
  });
});

// Start observing the document for added nodes
top10observer.observe(document.body, { childList: true, subtree: true });

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Function to start observing all attribute changes on the tooltip element
function observeTooltipChanges(tooltipElement) {
  const attributeObserver = new MutationObserver((mutationsList) => {
    for (let mutation of mutationsList) {
      if (mutation.type === "attributes") {
        const background = tooltipElement.style.background;
        const excludedProperties = ["left", "top"];
        const modifiedProperties = mutation.target.style;
      }
    }
  });

  attributeObserver.observe(tooltipElement, {
    attributes: true,
  });
}

// MutationObserver to detect when the tooltip element is added to the DOM
const tooltipObserver = new MutationObserver((mutationsList) => {
  for (let mutation of mutationsList) {
    for (let node of mutation.addedNodes) {
      if (
        node.nodeType === 1 &&
        node.classList.contains("game-tooltip_tooltip__w_58_")
      ) {
        let dmCheckbox = document.getElementById("Dark mode");

        if (dmCheckbox.checked) {
          // cursor label \/
          if (
            document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          ) {
            document.getElementsByClassName(
              "game-tooltip_tooltip__w_58_"
            )[0].style.background = "rgba(24, 26, 27, 0.75)";

            var spanElement = document
              .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
              .querySelector("span")
              .querySelector("strong");

            if (spanElement) {
              spanElement.style.color = "white";
              labelColor = false;
            }
          }
          const textColorWhite = "white";
          const nonLinkElements = document.querySelectorAll(
            ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
          );
          nonLinkElements.forEach((element) => {
            element.style.color = textColorWhite;
          });

          getData("RCOT").then((value) => {
            if (value == "KEEP") {
              customTable(false);
            } else {
              customTable(true);
            }
          });
        } else {
          // cursor label \/
          if (
            document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          ) {
            document.getElementsByClassName(
              "game-tooltip_tooltip__w_58_"
            )[0].style.background = "rgba(255, 255, 255, 0.75)";

            var spanElement = document
              .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
              .querySelector("span")
              .querySelector("strong");

            if (spanElement) {
              spanElement.style.color = "black";
              labelColor = false;
            }
          }
          const textColorBlack = "black";
          const nonLinkElements = document.querySelectorAll(
            ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
          );
          nonLinkElements.forEach((element) => {
            element.style.color = textColorBlack;
          });

          getData("RCOT").then((value) => {
            if (value == "KEEP") {
              customTable(false);
            } else {
              customTable(true);
            }
          });
        }

        observeTooltipChanges(node); // Start observing all attribute changes
        break;
      }
    }
  }
});

// Observe the entire document for added nodes
tooltipObserver.observe(document.body, {
  childList: true,
  subtree: true,
});

//////////////////////
//* Main functions */
////////////////////

// Function to commit data to browser storage:

function storeData(key, value) {
  return browser.storage.local.set({ [key]: value });
}

// Function to get data from browser storage:

function getData(key) {
  return browser.storage.local.get(key).then((result) => result[key]);
}

// Function to check if keys exist to prevent data overwriting:

function checkAndStoreData(key, value) {
  // Attempt to get the value associated with the key
  return browser.storage.local.get(key).then((result) => {
    // If the key already exists, return false and do not overwrite
    if (result[key] !== undefined) {
      return false;
    }

    // If the key does not exist, store the new data
    return browser.storage.local.set({ [key]: value }).then(() => {
      return true;
    });
  });
}

// Extension ui creation:

function createForm() {
  if (!document.getElementById("NekoAddon")) {
    const nekoMain = document.createElement("div");
    nekoMain.id = "NekoAddon";
    nekoMain.style.cssText = "position: absolute; top: 442px; left: 18px;";

    const nekoHeader = document.createElement("h2");
    nekoHeader.textContent = "Neko's Seterra Addons";
    nekoHeader.className = "header-class";
    nekoMain.appendChild(nekoHeader);

    const nekoForm = document.createElement("form");
    nekoMain.appendChild(nekoForm);

    const checkboxes = [
      {
        id: "Dark mode",
        text: "Dark mode",
        title:
          "Changes the background to a darker color, uncheck to set it to white.",
      },
      {
        id: "Map background",
        text: "Disable background",
        title: "Shows or hides the water background.",
      },
      {
        id: "Map padding",
        text: "Map padding",
        title:
          "Adds extra padding below the map for a less distracting user experience.",
      },
      {
        id: "Quick map reset",
        text: "Quick map reset",
        title: "Resets the map when the spacebar is pressed.",
      },
      {
        id: "Center map",
        text: "Center map",
        title: "Adds space on the left side of the map to center the map.",
      },
      {
        id: "Show top 10",
        text: "Show top 10",
        title:
          "Shows your top 10 best scores on the left of the map.\n!!! ONLY WORKS WHEN LOGGED IN",
      },
      // { id: 'Show cursor label', text: 'Show cursor label', title: 'Shows or hides the label that tracks the cursor.' },
      // { id: 'Show bold names', text: 'Show bold names', title: 'Shows or hides bold names.' },
      // { id: 'Show area flags', text: 'Show area flags', title: 'Shows or hides area flags.' },
      // { id: 'Show area names', text: 'Show area names', title: 'Shows or hides area names.' },
      {
        id: "Remove Click on text",
        text: 'Remove "Click on" text',
        title: 'Remove "Click on" text from cursor label',
      },
      // { id: 'Move extension down', text: 'Move extension down', title: 'Moves the extension (and top 10 if applicable) downwards so it doesn\'t overlap with the map.' },
      {
        id: "Use old font",
        text: "Use old font",
        title: "Replaces all™ text with the old font.",
      },
    ];

    const fragment = document.createDocumentFragment();

    checkboxes.forEach(({ id, text, title }) => {
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.id = id;

      const label = document.createElement("label");
      label.textContent = text;
      label.htmlFor = id;
      label.className = "checkbox-label";

      const helpText = document.createElement("label");
      helpText.textContent = "?";
      helpText.title = title;
      helpText.className = "neko-help-class";

      const wrapper = document.createElement("div");
      wrapper.className = "checkbox-wrapper";
      wrapper.appendChild(checkbox);
      wrapper.appendChild(label);
      wrapper.appendChild(helpText);

      fragment.appendChild(wrapper);
    });

    nekoForm.appendChild(fragment);

    const version = document.createElement("p");
    version.textContent = "v2.0 - dev wip ver. (Firefox)";
    version.className = "version-info";
    nekoMain.appendChild(version);

    const changelog = document.createElement("a");
    changelog.href =
      "https://github.com/NekoXIII/SeterraAddon/blob/main/changelog.md#1851";
    changelog.textContent = "Changelog";
    changelog.className = "changelog-link";
    changelog.target = "_blank";
    nekoMain.appendChild(changelog);

    document.body.appendChild(nekoMain);

    const style = document.createElement("style");
    style.textContent = `
            .neko-help-class { right: 0; position: absolute; }
            .neko-help-class:hover { cursor: pointer; }
            .header-class { padding-bottom: 10px; }
            .checkbox-wrapper { position: relative; display: flex; align-items: center; margin-bottom: 5px; }
            .checkbox-label { position: relative; left: 20px; }
            .version-info, .changelog-link { font-size: 12px; position: absolute; left: 5px; }
            .changelog-link { margin-top: 35px; }
        `;
    document.head.appendChild(style);

    nekoForm.addEventListener("change", (event) => {
      if (event.target.type === "checkbox") {
        handleCheckboxClick(event.target);
      }
    });
  }
}

// Extension ui checkbox handling:

function handleCheckboxClick(checkbox) {
  switch (checkbox.id) {
    case "Dark mode":
      if (checkbox.checked) {
        darkMode();
        storeData("DMode", "DARK");
      } else {
        lightMode();
        storeData("DMode", "LIGHT");
      }
      break;
    case "Map background":
      if (checkbox.checked) {
        mapBg(true);
        storeData("DBackground", "CUSTOM");
      } else {
        mapBg(false);
        storeData("DBackground", "KEEP");
      }
      break;
    case "Map padding":
      if (checkbox.checked) {
        mapPadding(true);
        storeData("MPadding", "CUSTOM");
      } else {
        mapPadding(false);
        storeData("MPadding", "KEEP");
      }
      break;
    case "Quick map reset":
      if (checkbox.checked) {
        mapReset(true);
        storeData("QMReset", "CUSTOM");
      } else {
        mapReset(false);
        storeData("QMReset", "KEEP");
      }
      break;
    case "Center map":
      if (checkbox.checked) {
        noLeftSpace(true);
        storeData("CMap", "CUSTOM");
      } else {
        noLeftSpace(false);
        storeData("CMap", "KEEP");
      }
      break;
    case "Show top 10":
      if (checkbox.checked) {
        customTable(true);
        storeData("ST10", "CUSTOM");
      } else {
        customTable(false);
        storeData("ST10", "KEEP");
      }
      break;
    case "Remove Click on text":
      if (checkbox.checked) {
        noClickOn(true);
        storeData("RCOT", "CUSTOM");
      } else {
        noClickOn(false);
        storeData("RCOT", "KEEP");
      }
      break;
    case "Use old font":
      if (checkbox.checked) {
        useOldFont(true);
        storeData("UOFont", "CUSTOM");
      } else {
        useOldFont(false);
        storeData("UOFont", "KEEP");
      }
      break;
  }
}

// Dark mode:

function darkMode() {
  const darkBackgroundColor = "#181A1B";
  const rgbaBackground = "rgba(24, 26, 27, 0.5)";
  const textColorWhite = "white";
  const textColorBlack = "black";
  const highlightColor1 = "#FF006E";
  const highlightColor2 = "#CC0058";

  // Store elements in variables to avoid repeated queries
  const gameContainerSmall = document.querySelector(
    "div.game-container_sizeSmall___C_u3"
  );
  const gameContainerMedium = document.querySelector(
    "div.game-container_sizeMedium__ZYDZN"
  );
  const seterraContent = document.querySelector("div.seterra_content__nGh5_");
  const gameHeader = document.querySelector(".game-header_wrapper__JDf24");
  const containerMedium = document.querySelector(
    "div.container_sizeMedium__Fwp9_"
  );
  const containerContent = document.querySelector(
    "div.container_content__Z3nYC"
  );
  const gamesListLinks = document.querySelectorAll(
    "a.games-list_viewAllLink__NQa_n b"
  );
  const nonLinkElements = document.querySelectorAll(
    ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
  );
  const tooltip = document.querySelector(".game-tooltip_tooltip__w_58_");
  const highscoreTable = document.querySelector(".highscore_table__oKrYg");
  const gameArea = document.querySelector(".game-area_gameArea__G2ABs");

  // Apply background colors
  if (
    gameContainerSmall &&
    gameContainerSmall.style.backgroundColor !== darkBackgroundColor
  ) {
    gameContainerSmall.style.backgroundColor = darkBackgroundColor;
  }
  if (
    gameContainerMedium &&
    gameContainerMedium.style.backgroundColor !== darkBackgroundColor
  ) {
    gameContainerMedium.style.backgroundColor = darkBackgroundColor;
  }
  if (seterraContent) {
    seterraContent.style.backgroundColor = darkBackgroundColor;
  }
  if (containerMedium) {
    containerMedium.style.backgroundColor = darkBackgroundColor;
  }
  if (containerContent) {
    containerContent.style.backgroundColor = darkBackgroundColor;
  }
  if (gameHeader) {
    gameHeader.style.background = rgbaBackground;
  }

  // Style text color in various sections
  gamesListLinks.forEach((element) => {
    element.style.color = textColorBlack;
  });
  nonLinkElements.forEach((element) => {
    element.style.color = textColorWhite;
  });

  // Tooltip styling
  if (tooltip) {
    tooltip.style.background = "rgba(24, 26, 27, 0.75)";
    const spanElement = tooltip.querySelector("span strong");
    if (spanElement) {
      spanElement.style.color = textColorWhite;
    }
  }

  // Highscore table and heading colors
  if (highscoreTable) {
    highscoreTable.style.backgroundColor = "rgba(0,0,0,0)";
  }

  // Game area text color
  if (gameArea) {
    gameArea.childNodes.forEach((element) => {
      element.style.color = textColorBlack;
    });
  }

  // Apply color highlights to specific elements by ID
  const nekoHeader = document.getElementsByClassName("header-class")[0];
  const version = document.getElementsByClassName("version-info")[0];
  if (nekoHeader) nekoHeader.style.color = highlightColor1;
  if (version) version.style.color = highlightColor2;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Light mode:

function lightMode() {
  const lightBackgroundColor = "#FFFFFF";
  const rgbaBackground = "rgba(231, 229, 228, 0.5)";
  const textColorBlack = "black";
  const textColorWhite = "white";
  const highlightColor1 = "#FF006E";
  const highlightColor2 = "#CC0058";

  // Store elements in variables to avoid repeated queries
  const gameContainerSmall = document.querySelector(
    "div.game-container_sizeSmall___C_u3"
  );
  const gameContainerMedium = document.querySelector(
    "div.game-container_sizeMedium__ZYDZN"
  );
  const seterraContent = document.querySelector("div.seterra_content__nGh5_");
  const gameHeader = document.querySelector(".game-header_wrapper__JDf24");
  const containerMedium = document.querySelector(
    "div.container_sizeMedium__Fwp9_"
  );
  const containerContent = document.querySelector(
    "div.container_content__Z3nYC"
  );
  const gamesListLinks = document.querySelectorAll(
    "a.games-list_viewAllLink__NQa_n b"
  );
  const nonLinkElements = document.querySelectorAll(
    ":not(a):not(input):not(.header-class):not(.version-info):not(.label-flash_labelVisible__8hi9E)"
  );
  const tooltip = document.querySelector(".game-tooltip_tooltip__w_58_");
  const highscoreTable = document.querySelector(".highscore_table__oKrYg");
  const gameArea = document.querySelector(".game-area_gameArea__G2ABs");

  // Apply background color to main containers if currently in dark mode
  if (
    gameContainerSmall &&
    gameContainerSmall.style.backgroundColor === "rgb(24, 26, 27)"
  ) {
    gameContainerSmall.style.backgroundColor = lightBackgroundColor;
  }
  if (
    gameContainerMedium &&
    gameContainerMedium.style.backgroundColor === "rgb(24, 26, 27)"
  ) {
    gameContainerMedium.style.backgroundColor = lightBackgroundColor;
  }
  if (seterraContent) {
    seterraContent.style.backgroundColor = lightBackgroundColor;
  }
  if (containerMedium) {
    containerMedium.style.backgroundColor = lightBackgroundColor;
  }
  if (containerContent) {
    containerContent.style.backgroundColor = lightBackgroundColor;
  }
  if (gameHeader) {
    gameHeader.style.background = rgbaBackground;
  }

  // Style text color in various sections
  gamesListLinks.forEach((element) => {
    element.style.color = textColorWhite;
  });
  nonLinkElements.forEach((element) => {
    element.style.color = textColorBlack;
  });

  // Tooltip styling
  if (tooltip) {
    tooltip.style.background = "rgba(231, 229, 228, 0.75)";
    const spanElement = tooltip.querySelector("span strong");
    if (spanElement) {
      spanElement.style.color = textColorBlack;
    }
  }

  // Highscore table and heading colors
  if (highscoreTable) {
    highscoreTable.style.backgroundColor = "rgba(0,0,0,0)";
  }

  // Game area text color
  if (gameArea) {
    gameArea.childNodes.forEach((element) => {
      element.style.color = textColorWhite;
    });
  }

  // Apply color highlights to specific elements by ID
  const nekoHeader = document.getElementsByClassName("header-class")[0];
  const version = document.getElementsByClassName("version-info")[0];
  if (nekoHeader) nekoHeader.style.color = highlightColor1;
  if (version) version.style.color = highlightColor2;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Disable background:

function mapBg(bool) {
  const elements = ["WATER", "BACKGROUND", "WATER_1_", "WATER_2_", "WATER_3_"];
  const color = bool ? "none" : "#a4d1dc";

  elements.forEach((id) => {
    const element = document.getElementById(id);
    if (element) {
      element.style.fill = color;
    }
  });
}

function mapBackgroundChecker(elements, callback) {
  const observer = new MutationObserver((mutationsList, observer) => {
    for (const mutation of mutationsList) {
      if (mutation.type === "childList") {
        for (const elementId of elements) {
          if (document.getElementById(elementId)) {
            callback(elementId); // Trigger callback with found element ID
            observer.disconnect(); // Stop observing once we find one element
            return;
          }
        }
      }
    }
  });

  // Start observing the document body for added nodes
  observer.observe(document.body, { childList: true, subtree: true });

  // Initial check in case elements are already present on page load
  for (const elementId of elements) {
    if (document.getElementById(elementId)) {
      callback(elementId);
      observer.disconnect();
      return;
    }
  }
}

// Map padding:

function mapPadding(bool) {
  if (document.getElementsByClassName("extra-info_extraInfo__80Tci")) {
    let mapSpace = document.getElementsByClassName(
      "extra-info_extraInfo__80Tci"
    );
    if (mapSpace[0]) {
      mapSpace[0].style.marginTop = "0px";
    }
    if (bool) {
      if (mapSpace[0]) {
        mapSpace[0].style.marginTop = "200px";
      }
    }
  }
}

// Quick map reset:

// Handler for easy EL removal.
function spaceKeyDownHandler(event) {
  if (event.code == "Space") {
    event.preventDefault();
    document
      .querySelectorAll(
        "button.button_button__aR6_e.button_variantSecondaryInverted__6G2ex.button_sizeSmall__MB_qj"
      )[1]
      .click();
    // [1] because [0] is the "Learn" button.
  }
}

function mapReset(bool) {
  if (bool) {
    document.addEventListener("keydown", spaceKeyDownHandler);
  } else {
    // Kill the EL
    document.removeEventListener("keydown", spaceKeyDownHandler);
  }
}

// Center map:

function zoomFunc(amnt, px, zoom) {
  if (zoom == amnt) {
    if (
      document.querySelectorAll(
        "aside.seterra_sidebarLeft__wQo_r.seterra_sidebar__p6xf1.seterra_adContainerLeft__zTLsS"
      )[0]
    ) {
      document.querySelectorAll(
        "aside.seterra_sidebarLeft__wQo_r.seterra_sidebar__p6xf1.seterra_adContainerLeft__zTLsS"
      )[0].style.width = px + "px";
    }
    if (amnt <= 1.4) {
      if (
        document.querySelectorAll(
          "aside.seterra_sidebarRight__bXW1x.seterra_sidebar__p6xf1.seterra_adContainerRight__lDew4"
        )[0]
      ) {
        document.querySelectorAll(
          "aside.seterra_sidebarRight__bXW1x.seterra_sidebar__p6xf1.seterra_adContainerRight__lDew4"
        )[0].style.display = "block";
      }
    } else {
      if (
        document.querySelectorAll(
          "aside.seterra_sidebarRight__bXW1x.seterra_sidebar__p6xf1.seterra_adContainerRight__lDew4"
        )[0]
      ) {
        document.querySelectorAll(
          "aside.seterra_sidebarRight__bXW1x.seterra_sidebar__p6xf1.seterra_adContainerRight__lDew4"
        )[0].style.display = "none";
      }
    }
  }
}

///  Removal of empty space next to map.
function noLeftSpace(bool) {
  if (bool) {
    let zoom = window.devicePixelRatio.toFixed(1); // 100% = 1.0, 50% = 0.5

    zoomFunc(0.5, 410, zoom); // 50%
    zoomFunc(0.6, 410, zoom); // 50%
    zoomFunc(0.7, 400, zoom); // 70%
    zoomFunc(0.8, 400, zoom); // 80%
    zoomFunc(0.9, 400, zoom); // 90%
    zoomFunc(1.0, 400, zoom); // 100%
    zoomFunc(1.1, 400, zoom); // 110%
    zoomFunc(1.2, 380, zoom); // 120%
    zoomFunc(1.3, 315, zoom); // 130%
    zoomFunc(1.4, 267, zoom); // 140%
    zoomFunc(1.5, 267, zoom); // 150+%
  } else {
    if (
      document.querySelectorAll(
        "aside.seterra_sidebarLeft__wQo_r.seterra_sidebar__p6xf1.seterra_adContainerLeft__zTLsS"
      )[0]
    ) {
      document.querySelectorAll(
        "aside.seterra_sidebarLeft__wQo_r.seterra_sidebar__p6xf1.seterra_adContainerLeft__zTLsS"
      )[0].style.width = "160px";
    }
  }
}

// Show top 10:

function customTable(bool) {
  if (bool) {
    if (document.getElementsByClassName("highscore_table__oKrYg")[0]) {
      document.getElementsByClassName(
        "highscore_heading__mqofP"
      )[0].style.position = "absolute";
      document.getElementsByClassName(
        "highscore_heading__mqofP"
      )[0].style.left = "23px";

      document.getElementsByClassName(
        "highscore_table__oKrYg"
      )[0].style.position = "absolute";
      document.getElementsByClassName("highscore_table__oKrYg")[0].style.left =
        "0px";
    }
    if (document.getElementsByClassName("highscore_heading__mqofP")[0]) {
      document.getElementsByClassName("highscore_heading__mqofP")[0].style.top =
        "808px";
    }
    if (document.getElementsByClassName("highscore_table__oKrYg")[0]) {
      document.getElementsByClassName("highscore_table__oKrYg")[0].style.top =
        "824px";
    }
  } else {
    // if (document.getElementsByClassName("highscore_table__oKrYg")[0]) {
    //   if (
    //     document.getElementsByClassName("highscore_heading__mqofP")[0].style
    //       .position == "absolute"
    //   ) {
    //     document.location.reload();
    //   }
    // }
  }
}

// Remove "Click on" Text:
function noClickOn(bool) {
  if (bool) {
    if (document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]) {
      if (
        document
          .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          .querySelector("span")
      ) {
        document
          .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          .querySelector("span").childNodes[0].textContent = "";
      }
    }
  } else {
    if (document.getElementsByClassName("game-tooltip_tooltip__w_58_")[0]) {
      if (
        document
          .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          .querySelector("span")
      ) {
        document
          .getElementsByClassName("game-tooltip_tooltip__w_58_")[0]
          .querySelector("span").childNodes[0].textContent = "Click on ";
      }
    }
  }
}

// Font switcher:

function useOldFont(enable) {
  if (enable) {
    document.body.classList.add("use-old-font");
  } else {
    document.body.classList.remove("use-old-font");
  }
}

////////////////////////////////
/* Initial command execution */
//////////////////////////////

// Extension defaults:

dataList = {
  DMode: "DARK",
  DBackground: "KEEP",
  MPadding: "CUSTOM",
  QMReset: "CUSTOM",
  CMap: "CUSTOM",
  ST10: "CUSTOM",
  RCOT: "KEEP",
  UOFont: "CUSTOM",
};

// Commit data to browser storage:

// Check if the first key does NOT exist:
checkAndStoreData("DMode", "DARK").then((result) => {
  if (result) {
    // First key is not present, write defaults to storage.
    for (let key in dataList) {
      if (dataList.hasOwnProperty(key)) {
        storeData(key, dataList[key]);
      }
    }
  }
});

// Create the extension ui:

createForm();

// Clear background for page consistency:

mapBg(false);

// Apply settings:

function applySettings() {
  getData("DMode").then((value) => {
    if (value == "DARK") {
      darkMode();
      document.getElementById("Dark mode").checked = true;
    } else {
      lightMode();
      document.getElementById("Dark mode").checked = false;
    }
  });
  getData("DBackground").then((value) => {
    if (value == "KEEP") {
      mapBg(false);
      document.getElementById("Map background").checked = false;
    } else {
      mapBg(true);
      document.getElementById("Map background").checked = true;
    }
  });
  getData("MPadding").then((value) => {
    if (value == "KEEP") {
      mapPadding(false);
      document.getElementById("Map padding").checked = false;
    } else {
      mapPadding(true);
      document.getElementById("Map padding").checked = true;
    }
  });
  getData("QMReset").then((value) => {
    if (value == "KEEP") {
      mapReset(false);
      document.getElementById("Quick map reset").checked = false;
    } else {
      mapReset(true);
      document.getElementById("Quick map reset").checked = true;
    }
  });
  getData("CMap").then((value) => {
    if (value == "KEEP") {
      noLeftSpace(false);
      document.getElementById("Center map").checked = false;
    } else {
      noLeftSpace(true);
      document.getElementById("Center map").checked = true;
    }
  });
  getData("ST10").then((value) => {
    if (value == "KEEP") {
      customTable(false);
      document.getElementById("Show top 10").checked = false;
    } else {
      customTable(true);
      document.getElementById("Show top 10").checked = true;
    }
  });
  getData("RCOT").then((value) => {
    if (value == "KEEP") {
      noClickOn(false);
      document.getElementById("Remove Click on text").checked = false;
    } else {
      noClickOn(true);
      document.getElementById("Remove Click on text").checked = true;
    }
  });
  getData("UOFont").then((value) => {
    if (value == "KEEP") {
      useOldFont(false);
      document.getElementById("Use old font").checked = false;
    } else {
      useOldFont(true);
      document.getElementById("Use old font").checked = true;
    }
  });
}

applySettings();
